MapResizeDialog.minSize = 0
MapResizeDialog.maxSize = 40000
require('开屏菜单');
//来自爬爬的模组